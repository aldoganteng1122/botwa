/**
 * group.js - group-level features that persist settings and simple vote/poll.
 * Real group member actions (add/kick/promote/demote) will be attempted via the sock object in case.js.
 */

function setWelcome(groupObj, text) {
  groupObj.welcome = text;
  return 'Welcome message diset.';
}

function setGoodbye(groupObj, text) {
  groupObj.goodbye = text;
  return 'Goodbye message diset.';
}

function toggle(groupObj, key, val) {
  groupObj[key] = val;
  return `${key} => ${val}`;
}

module.exports = { setWelcome, setGoodbye, toggle };
