/**
 * storage.js - simple JSON persistent storage
 * Data layout:
 * {
 *   users: { "<id>": { rpg: {...}, inventory: [...], lastDaily: 0, ... } },
 *   groups: { "<jid>": { settings... } },
 *   meta: {}
 * }
 */
const fs = require('fs');
const path = require('path');
const { writeFileAtomic } = require('./function');

const DATA_PATH = path.join(__dirname, '..', 'data.json');

function ensure() {
  if (!fs.existsSync(DATA_PATH)) {
    const initial = { users: {}, groups: {}, meta: {} };
    writeFileAtomic(DATA_PATH, JSON.stringify(initial, null, 2));
  }
}

function read() {
    try {
        if (!fs.existsSync(filePath)) {
            return { users: {}, groups: {}, owners: [] };
        }
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        console.error('Error reading storage:', e);
        return { users: {}, groups: {}, owners: [] };
    }
}

function write(data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error('Error writing to storage:', e);
    }
}

function getUser(id) {
    const db = read();
    if (!db.users[id]) {
        db.users[id] = { id, rpg: { name: id, ...require('./rpg').initialStats() }, limit: 10, xp: 0 };
        write(db);
    }
    return db.users[id];
}

function saveUser(id, user) {
    const db = read();
    db.users[id] = user;
    write(db);
}

function getGroup(jid) {
  const db = read();
  if (!db.groups[jid]) {
    db.groups[jid] = {
      welcome: null,
      goodbye: null,
      antilink: false,
      antilinkgc: false,
      antitoxic: false,
      settings: {}
    };
    write(db);
  }
  return db.groups[jid];
}

function saveGroup(jid, groupObj) {
  const db = read();
  db.groups[jid] = groupObj;
  write(db);
}

module.exports = { getUser, saveUser, getGroup, saveGroup, read, write, DATA_PATH };
