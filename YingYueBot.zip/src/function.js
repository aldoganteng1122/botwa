/**
 * function.js - helper utilities
 */
const fs = require('fs');

function parseCommand(text = '', prefix = '!') {
  if (typeof text !== 'string') return null;
  if (!text.startsWith(prefix)) return null;
  const without = text.slice(prefix.length).trim();
  if (!without) return null;
  const [cmd, ...args] = without.split(/\s+/);
  return { cmd: cmd.toLowerCase(), args };
}

function randomPick(arr = []) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function formatTime(date = new Date()) {
  return date.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
}

function safeText(text) {
  return String(text || '');
}

// atomic write
function writeFileAtomic(path, data) {
  const tmp = path + '.tmp';
  fs.writeFileSync(tmp, data, 'utf8');
  fs.renameSync(tmp, path);
}

module.exports = { parseCommand, randomPick, formatTime, safeText, writeFileAtomic };
