/**
 * rpg.js - implementasi fitur RPG (stateful)
 * Menyediakan helper yang menerima user object dari storage dan memodifikasinya.
 */

function gainExp(user, amount) {
  user.rpg.exp += amount;
  // simple level calc: level up every 100 exp
  while (user.rpg.exp >= 100) {
    user.rpg.exp -= 100;
    user.rpg.level += 1;
    user.rpg.hp = Math.min(100 + (user.rpg.level-1)*10, 999);
  }
}

function cost(user, gold) {
  if (user.rpg.gold >= gold) {
    user.rpg.gold -= gold;
    return true;
  }
  return false;
}

module.exports = {
  // 1 status
  status: (user) => {
    return `血量 HP: ${user.rpg.hp}\n经验 EXP: ${user.rpg.exp}\n等级 Level: ${user.rpg.level}\n金币 Gold: ${user.rpg.gold}\n体力 Energy: ${user.rpg.energy}`;
  },

  // 2 daily
  daily: (user, now) => {
    const DAY = 24*60*60*1000;
    if (now - (user.lastDaily || 0) < DAY) return { ok: false, msg: '已经领取过今日奖励 (Daily sudah diambil).' };
    user.lastDaily = now;
    user.rpg.gold += 50;
    user.rpg.exp += 20;
    return { ok: true, msg: '领取成功! 获得 50 Gold & 20 EXP.' };
  },

  // 3 train
  train: (user) => {
    if (user.rpg.energy < 10) return '体力不足 (Not enough energy).';
    user.rpg.energy -= 10;
    user.rpg.exp += 15;
    return '你训练了一会儿，获得 15 EXP。';
  },

  // 4 quest start
  questStart: (user, name) => {
    user.currentQuest = { name: name || '未知任务', progress: 0 };
    return `任务已开始: ${user.currentQuest.name}`;
  },

  // 5 quest progress / finish
  questProgress: (user) => {
    if (!user.currentQuest) return '没有任务正在进行。';
    user.currentQuest.progress += 1;
    if (user.currentQuest.progress >= 3) {
      user.rpg.gold += 100;
      user.rpg.exp += 50;
      const name = user.currentQuest.name;
      delete user.currentQuest;
      return `任务完成! 奖励: 100 Gold & 50 EXP. (任务: ${name})`;
    }
    return `任务进度: ${user.currentQuest.progress}/3`;
  },

  // 6 hunt
  hunt: (user) => {
    if (user.rpg.energy < 5) return '体力不足 (Not enough energy).';
    user.rpg.energy -= 5;
    user.rpg.exp += 10;
    user.rpg.gold += 20;
    return '你出发狩猎，获得 20 Gold & 10 EXP.';
  },

  // 7 fish
  fish: (user) => {
    if (user.rpg.energy < 4) return '体力不足.';
    user.rpg.energy -= 4;
    user.inventory.push('鱼');
    user.rpg.exp += 8;
    return '你钓到一条鱼。';
  },

  // 8 mine
  mine: (user) => {
    if (user.rpg.energy < 6) return '体力不足.';
    user.rpg.energy -= 6;
    user.inventory.push('矿石');
    user.rpg.exp += 12;
    return '你采到矿石。';
  },

  // 9 craft
  craft: (user, item) => {
    // simple craft: combine 2x矿石 -> 宝剑
    const inv = user.inventory || [];
    if (item === '宝剑') {
      const idx1 = inv.indexOf('矿石');
      const idx2 = inv.indexOf('矿石', idx1+1);
      if (idx1 >=0 && idx2 >=0) {
        inv.splice(idx2,1);
        inv.splice(idx1,1);
        inv.push('宝剑');
        user.rpg.exp += 30;
        return '合成成功: 宝剑';
      }
      return '材料不足 (Butuh 2x 矿石).';
    }
    return '无法合成 (Unknown recipe).';
  },

  // 10 shop (list)
  shop: () => {
    return [
      { id: 'potion', name: '药水', price: 30 },
      { id: 'sword', name: '短剑', price: 200 },
      { id: 'energy', name: '体力包', price: 50 }
    ];
  },

  // 11 buy
  buy: (user, id) => {
    const items = module.exports.shop();
    const item = items.find(i=>i.id===id);
    if (!item) return '商品不存在.';
    if (!cost(user, item.price)) return '金币不足.';
    user.inventory.push(item.name);
    return `购买成功: ${item.name}`;
  },

  // 12 sell
  sell: (user, name) => {
    const idx = user.inventory.indexOf(name);
    if (idx < 0) return '没有该物品.';
    user.inventory.splice(idx,1);
    user.rpg.gold += 10;
    return `售出 ${name}，获得 10 Gold.`;
  },

  // 13 inventory
  inventory: (user) => {
    return `物品栏: ${user.inventory.length ? user.inventory.join(', ') : '空'}`;
  },

  // 14 duel (simple)
  duel: (user, opponent) => {
    // opponent is object
    const roll1 = Math.floor(Math.random()*20) + user.rpg.level;
    const roll2 = Math.floor(Math.random()*20) + (opponent.rpg?opponent.rpg.level:1);
    if (roll1 >= roll2) {
      user.rpg.exp += 20;
      user.rpg.gold += 30;
      return '你赢了决斗! +20 EXP +30 Gold.';
    } else {
      user.rpg.hp = Math.max(0, user.rpg.hp - 10);
      return '你失利了，失去 10 HP.';
    }
  },

  // 15 heal
  heal: (user) => {
    if (user.rpg.gold < 20) return '金币不足.';
    user.rpg.gold -= 20;
    user.rpg.hp = Math.min(100 + (user.rpg.level-1)*10, 999);
    return '治疗完成，HP 已恢复。';
  },

  // 16 rest
  rest: (user) => {
    user.rpg.energy = Math.min(100, user.rpg.energy + 30);
    return '你休息了，体力恢复 30.';
  },

  // 17 upgrade
  upgrade: (user) => {
    if (user.rpg.gold < 150) return '金币不足升级.';
    user.rpg.gold -= 150;
    user.rpg.level += 1;
    user.rpg.hp += 20;
    return '升级成功! Level +1.';
  },

  // 18 stats
  stats: (user) => {
    return `详细统计:\nLevel ${user.rpg.level} | EXP ${user.rpg.exp} | Gold ${user.rpg.gold}`;
  },

  // 19 craftList (recipes)
  recipes: () => {
    return ['宝剑: 2x 矿石'];
  },

  // 20 summon (pet)
  summon: (user, petName) => {
    const name = petName || '小灵兽';
    user.pets.push({ name, hp: 50 });
    return `你召唤了宠物: ${name}`;
  },

  // 21 petStatus
  petStatus: (user) => {
    return user.pets.length ? user.pets.map(p=>`${p.name} HP:${p.hp}`).join('\n') : '没有宠物';
  },

  // 22 tame (attempt to tame)
  tame: (user) => {
    const ok = Math.random() < 0.4;
    if (ok) {
      user.pets.push({ name: '野生灵兽', hp: 40 });
      return '驯服成功!';
    }
    return '驯服失败.';
  },

  // 23 arena (boss fight)
  boss: (user) => {
    const bossHp = 200;
    const dmg = Math.floor(Math.random()*40)+10 + user.rpg.level;
    if (dmg >= bossHp) {
      user.rpg.gold += 300;
      user.rpg.exp += 200;
      return '你击败了世界Boss! 大量奖励!';
    }
    user.rpg.hp = Math.max(0, user.rpg.hp - 50);
    return 'Boss 太强，逃跑了，失去 50 HP.';
  },

  // 24 explore
  explore: (user) => {
    user.rpg.exp += 12;
    const found = Math.random() < 0.3 ? '宝箱' : '空地';
    if (found === '宝箱') {
      user.rpg.gold += 80;
      return '探险发现宝箱，获得 80 Gold!';
    }
    return '探险无所得。';
  },

  // 25 skill (list)
  skills: () => ['strike: 伤害型', 'heal: 回复型'],

  // 26 useSkill (simple)
  useSkill: (user, skill) => {
    if (skill === 'heal') {
      user.rpg.hp = Math.min(user.rpg.hp + 30, 999);
      return '使用技能: 回复 30 HP.';
    }
    if (skill === 'strike') {
      user.rpg.exp += 10;
      return '使用技能: 造成伤害 (模拟), 获得 10 EXP.';
    }
    return '未知技能.';
  },

  // 27 leaderboard (simple sort)
  leaderboard: (allUsers) => {
    const arr = Object.entries(allUsers).map(([id,u])=>({ id, level: u.rpg.level, exp: u.rpg.exp }));
    arr.sort((a,b)=> (b.level*100 + b.exp) - (a.level*100 + a.exp));
    return arr.slice(0,10).map((x,i)=>`${i+1}. ${x.id} - L${x.level} (${x.exp}exp)`).join('\n');
  },

  // 28 give (transfer gold)
  give: (fromUser, toUser, amount) => {
    amount = Number(amount) || 0;
    if (fromUser.rpg.gold < amount) return '金币不足.';
    fromUser.rpg.gold -= amount;
    toUser.rpg.gold += amount;
    return `转账成功: ${amount} Gold.`;
  },

  // export helpers
  gainExp, cost
};
