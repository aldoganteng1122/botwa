/**
 * index.js - entrypoint
 * Bisa login via QR atau pairing code nomor WhatsApp
 */
const cfg = require('../config/config.json');
const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');
const { handleCommand } = require('../case');
const { checkBotBirthday } = require("./birthday");
const cfg = require('./config/config.json');
const { parseCommand, formatTime } = require('./function');
const storage = require('./storage');
const rpg = require('./rpg');
const groupUtil = require('./group');
const limit = require('./limit'); // New
const owner = require('./owner'); // New
const level = require('./level'); // New


const MOCK = !!process.env.MOCK;

async function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(question, ans => {
    rl.close();
    resolve(ans.trim());
  }));
}

if (MOCK) {
  console.log(`[MOCK MODE] ${cfg.botName} 启动 (prefix: ${cfg.prefix})`);
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.on('line', async (line) => {
    try {
      await handleCommand({ from: 'local@mock', text: line.trim(), reply: console.log, sock: null, msg: null });
    } catch (e) {
      console.error('handler error', e);
    }
  });
  return;
}

(async () => {
  try {
    const { version } = await fetchLatestBaileysVersion();
    const { state, saveCreds } = await useMultiFileAuthState('./session');

    let loginMethod = await ask("Login via (1) QR atau (2) Pairing nomor? (ketik 1/2): ");

    const sock = makeWASocket({
      version,
      logger: pino({ level: 'silent' }),
      printQRInTerminal: loginMethod === '1',
      auth: state
    });

    if (loginMethod === '2') {
      let phoneNumber = await ask("Masukkan nomor WhatsApp (contoh: 6281234567890): ");
      phoneNumber = phoneNumber.replace(/\D/g, '');
      if (!phoneNumber.startsWith('62')) {
        console.log("Nomor harus diawali 62 (kode negara Indonesia)");
        process.exit(1);
      }

      console.log(`Meminta pairing code untuk ${phoneNumber}...`);
      const code = await sock.requestPairingCode(phoneNumber);
      console.log(`Kode pairing WA: ${code}`);
      console.log("Masukkan kode ini di WhatsApp Anda: Perangkat Tertaut → Tautkan Perangkat");
    }

    sock.ev.on('creds.update', saveCreds);

sock.ev.on('connection.update', (u) => {
  console.log('connection.update', u.connection);
  
  if (u.connection === 'open') {
    startBirthdayWatcher(sock); // mulai pemantauan ultah
  }
});

    sock.ev.on('messages.upsert', async (m) => {
      try {
        const message = m.messages && m.messages[0];
        if (!message || message.key?.remoteJid === 'status@broadcast') return;
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        const from = message.key.remoteJid;
        await handleCommand({ from, text, reply: async (txt) => sock.sendMessage(from, { text: txt }), sock, msg: message });
      } catch (e) {
        console.error('message handler error', e);
      }
    });

    console.log('Socket siap.');
  } catch (e) {
    console.error('Startup error', e);
    console.log('Untuk testing lokal jalankan: MOCK=true node src/index.js');
  }
})();