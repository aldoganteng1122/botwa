// src/birthday.js
const { delay } = require("@whiskeysockets/baileys");

let alreadySent = false; // biar ga ngirim berulang kali di hari yang sama

async function startBirthdayWatcher(sock) {
    setInterval(async () => {
        const today = new Date();
        const day = today.getDate();
        const month = today.getMonth() + 1; // Januari = 0, jadi +1

        if (day === 20 && month === 8) {
            if (!alreadySent) {
                console.log("[BOT BIRTHDAY] 🎉 Hari ini ultah bot! Mengirim pesan ke semua grup...");
                try {
                    const groups = await sock.groupFetchAllParticipating();
                    const groupIds = Object.keys(groups);

                    for (let id of groupIds) {
                        await sock.sendMessage(id, { 
                            text: "🎉 Halo semua! Hari ini adalah ulang tahun bot Ying Yue! 🎂✨ Terima kasih sudah memakai bot ini ❤️" 
                        });
                        await delay(1500);
                    }

                    alreadySent = true;
                    console.log(`[BOT BIRTHDAY] Pesan terkirim ke ${groupIds.length} grup`);
                } catch (err) {
                    console.error("[BOT BIRTHDAY] Gagal mengirim:", err);
                }
            }
        } else {
            alreadySent = false; // reset tiap hari bukan 20 Agustus
        }
    }, 60 * 1000); // cek tiap 1 menit
}

module.exports = { startBirthdayWatcher };