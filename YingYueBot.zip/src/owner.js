// src/owner.js

const storage = require('./storage');
const cfg = require('../config/config.json');

function isOwner(userId) {
    const db = storage.read();
    return cfg.ownerName === userId || (db.owners && db.owners.includes(userId));
}

function addOwner(userId) {
    const db = storage.read();
    db.owners = db.owners || [];
    if (db.owners.includes(userId)) {
        return 'User ini sudah menjadi owner.';
    }
    db.owners.push(userId);
    storage.write(db);
    return `User ${userId} berhasil ditambahkan sebagai owner.`;
}

function removeOwner(userId) {
    const db = storage.read();
    db.owners = db.owners || [];
    const index = db.owners.indexOf(userId);
    if (index === -1) {
        return 'User ini bukan owner.';
    }
    db.owners.splice(index, 1);
    storage.write(db);
    return `User ${userId} berhasil dihapus dari daftar owner.`;
}

function listOwners() {
    const db = storage.read();
    const ownerList = db.owners || [];
    return `Daftar Owner Bot:\n${ownerList.join('\n')}`;
}

module.exports = {
    isOwner,
    addOwner,
    removeOwner,
    listOwners
};
