// src/level.js

const storage = require('./storage');

const XP_PER_LEVEL = 100;
const XP_PER_MESSAGE = 5;

function getLevelInfo(xp) {
    let level = 0;
    let requiredXp = XP_PER_LEVEL;
    while (xp >= requiredXp) {
        xp -= requiredXp;
        level++;
        requiredXp = XP_PER_LEVEL + (level * 50); // Increase required XP for each level
    }
    return { level, xp };
}

function addXp(userId, amount = XP_PER_MESSAGE) {
    const user = storage.getUser(userId);
    const oldLevel = getLevelInfo(user.xp || 0).level;
    user.xp = (user.xp || 0) + amount;
    storage.saveUser(userId, user);

    const newLevel = getLevelInfo(user.xp).level;
    if (newLevel > oldLevel) {
        return { leveledUp: true, newLevel };
    }
    return { leveledUp: false };
}

function getLevelStatus(userId) {
    const user = storage.getUser(userId);
    const { level, xp } = getLevelInfo(user.xp || 0);
    const xpNeeded = (level + 1) * XP_PER_LEVEL + (level * 50);
    return `Level Anda saat ini: *${level}*\nXP: *${xp}* / ${xpNeeded}`;
}

module.exports = {
    addXp,
    getLevelStatus
};
