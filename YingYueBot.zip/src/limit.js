// src/limit.js

const storage = require('./storage');

function addLimit(userId, amount) {
    const user = storage.getUser(userId);
    user.limit = (user.limit || 0) + amount;
    storage.saveUser(userId, user);
    return `Limit untuk user ID ${userId} ditambahkan sebesar ${amount}. Total limit: ${user.limit}`;
}

function checkLimit(userId) {
    const user = storage.getUser(userId);
    const limit = user.limit || 0;
    return `Sisa limit Anda adalah ${limit}.`;
}

function useLimit(userId) {
    const user = storage.getUser(userId);
    if (!user.limit || user.limit <= 0) {
        return false;
    }
    user.limit -= 1;
    storage.saveUser(userId, user);
    return true;
}

function deleteLimit(userId) {
    const user = storage.getUser(userId);
    user.limit = 0;
    storage.saveUser(userId, user);
    return `Limit untuk user ID ${userId} telah direset.`;
}

module.exports = {
    addLimit,
    checkLimit,
    useLimit,
    deleteLimit
};
