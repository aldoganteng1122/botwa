const cfg = require('./config/config.json');
const { parseCommand, formatTime } = require('./src/function');
const storage = require('./src/storage');
const rpg = require('./src/rpg');
const groupUtil = require('./src/group');
const limit = require('./src/limit'); // New
const owner = require('./src/owner'); // New
const level = require('./src/level'); // New

// Library tambahan
const readline = require('readline');
const axios = require('axios');
const pino = require('pino');
const fs = require('fs');

// Baileys
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    delay
} = require('@whiskeysockets/baileys');

async function handleCommand({ from, text = '', reply = console.log, sock = null, msg = null, args = [], remoteJid = null }) {
  const parsed = parseCommand(text, cfg.prefix);
  if (!parsed) return;
  const { cmd } = parsed;
  args = parsed.args;

  // helper to get user id normalized (for storage). Use from or args[0]
  const uid = (from || 'unknown').toString();

  // For group commands, group jid is `from` when message came from group
  const gid = (from && from.includes('@g.us')) ? from : null;

  try {
// ... inside handleCommand function

// Add XP to user for every message
const user = storage.getUser(uid);
const { leveledUp, newLevel } = level.addXp(uid);
if (leveledUp) {
    reply(`🎉 Selamat! Anda naik ke level ${newLevel}!`);
}

switch (cmd) {
    case 'addowner': {
        if (!owner.isOwner(uid)) return reply('Maaf, hanya pemilik bot yang bisa menggunakan perintah ini.');
        const targetId = args[0];
        if (!targetId) return reply('Gunakan: !addowner <@id>');
        return reply(owner.addOwner(targetId));
    }
    break;
    
    case 'delowner': {
        if (!owner.isOwner(uid)) return reply('Maaf, hanya pemilik bot yang bisa menggunakan perintah ini.');
        const targetId = args[0];
        if (!targetId) return reply('Gunakan: !delowner <@id>');
        return reply(owner.removeOwner(targetId));
    }
    break;

    case 'listowner': {
        return reply(owner.listOwners());
    }
    break;

    case 'addlimit': {
        if (!owner.isOwner(uid)) return reply('Maaf, hanya pemilik bot yang bisa menggunakan perintah ini.');
        const targetId = args[0];
        const amount = parseInt(args[1], 10);
        if (!targetId || isNaN(amount)) return reply('Gunakan: !addlimit <@id> <jumlah>');
        return reply(limit.addLimit(targetId, amount));
    }
    break;
    
    case 'dellimit': {
        if (!owner.isOwner(uid)) return reply('Maaf, hanya pemilik bot yang bisa menggunakan perintah ini.');
        const targetId = args[0];
        if (!targetId) return reply('Gunakan: !dellimit <@id>');
        return reply(limit.deleteLimit(targetId));
    }
    break;
    
    case 'ceklimit': {
        return reply(limit.checkLimit(uid));
    }
    break;
    
    // New Level Commands
    case 'level': {
        return reply(level.getLevelStatus(uid));
    }
    break;

      // ----------------------
      // Basic
      // ----------------------
      case 'ping':
        return reply('Pong! Ying Yue 映月 👋');

case 'help':
    return reply(`
┏━〔 📜 COMMAND LIST 〕━━┓
┃ Prefix: ${cfg.prefix}
┃ Bot Name: ${cfg.botName}
┃ Date: ${new Date().toLocaleDateString()}
┣━━━━━━━━━━━━━━━━━━━
┃  🎮 RPG Commands
┃  ╭──────────────
┃  │ ${cfg.prefix}rpg_status
┃  │ ${cfg.prefix}rpg_daily
┃  │ ${cfg.prefix}rpg_train
┃  │ ${cfg.prefix}rpg_hunt
┃  │ ${cfg.prefix}rpg_fish
┃  │ ${cfg.prefix}rpg_mine
┃  │ ${cfg.prefix}rpg_craft <item>
┃  │ ${cfg.prefix}rpg_shop
┃  │ ${cfg.prefix}rpg_buy <id>
┃  │ ${cfg.prefix}rpg_sell <item>
┃  │ ${cfg.prefix}rpg_inv
┃  │ ${cfg.prefix}rpg_duel <@id>
┃  │ ${cfg.prefix}rpg_heal
┃  │ ${cfg.prefix}rpg_rest
┃  │ ${cfg.prefix}rpg_upgrade
┃  │ ${cfg.prefix}rpg_stats
┃  │ ${cfg.prefix}rpg_recipes
┃  │ ${cfg.prefix}rpg_summon <name>
┃  │ ${cfg.prefix}rpg_pet
┃  │ ${cfg.prefix}rpg_tame
┃  │ ${cfg.prefix}rpg_boss
┃  │ ${cfg.prefix}rpg_explore
┃  │ ${cfg.prefix}rpg_skills
┃  │ ${cfg.prefix}rpg_useskill <skill>
┃  │ ${cfg.prefix}rpg_lb
┃  │ ${cfg.prefix}rpg_give <@id> <amount>
┃  │ ${cfg.prefix}rpg_qstart <name>
┃  │ ${cfg.prefix}rpg_qnext
┃  ╰──────────────
┣━━━━━━━━━━━━━━━━━━━
┃  👥 Group Commands
┃  ╭──────────────
┃  │ ${cfg.prefix}welcome_set <text>
┃  │ ${cfg.prefix}goodbye_set <text>
┃  │ ${cfg.prefix}welcome
┃  │ ${cfg.prefix}goodbye
┃  │ ${cfg.prefix}antilink_on / off
┃  │ ${cfg.prefix}antilinkgc_on / off
┃  │ ${cfg.prefix}antitoxic_on / off
┃  │ ${cfg.prefix}add <number>
┃  │ ${cfg.prefix}kick <@id>
┃  │ ${cfg.prefix}promote <@id>
┃  │ ${cfg.prefix}demote <@id>
┃  │ ${cfg.prefix}tagall
┃  │ ${cfg.prefix}setname <name>
┃  │ ${cfg.prefix}setdesc <text>
┃  │ ${cfg.prefix}mute / unmute
┃  │ ${cfg.prefix}vote_start <topic>
┃  │ ${cfg.prefix}vote <yes|no>
┃  │ ${cfg.prefix}vote_end
┃  │ ${cfg.prefix}poll <question>
┃  │ ${cfg.prefix}warn <@id>
┃  │ ${cfg.prefix}clearwarns <@id>
┃  │ ${cfg.prefix}group_settings
┃  ╰──────────────
┗━━━━━━━━━━━━━━━━━━━
`);
        break;
      
      case 'menu':
    const sections = [
        {
            title: "📜 Main Menu",
            rows: [
                { title: "📋 All Menu", rowId: `${cfg.prefix}allmenu`, description: "Lihat semua perintah bot" },
                { title: "⚔️ RPG Menu", rowId: `${cfg.prefix}rpgmenu`, description: "Fitur game RPG seru" },
                { title: "👥 Group Menu", rowId: `${cfg.prefix}groupmenu`, description: "Pengaturan & fitur grup" },
                { title: "🎭 Fun Menu", rowId: `${cfg.prefix}funmenu`, description: "Fitur hiburan" },
                { title: "🛠 Tools Menu", rowId: `${cfg.prefix}toolsmenu`, description: "Alat bantu & utilitas" },
            ],
        },
        {
            title: "🔗 Links & Info",
            rows: [
                { title: "🌐 Website", rowId: "link_website", description: "Kunjungi situs resmi kami" },
                { title: "💬 Grup Official", rowId: "link_group", description: "Gabung ke grup support" },
                { title: "📢 Channel Update", rowId: "link_channel", description: "Info update terbaru" },
            ],
        }
    ];

    const listMessage = {
    text: `*🤖 ${cfg.botName} Main Menu*\n
Bot ini dibuat oleh: *${cfg.ownerName}*
Versi: *${cfg.version}*
Tanggal aktif: ${new Date().toLocaleDateString('id-ID')}
Prefix: *${cfg.prefix}*\n
Pilih kategori menu di bawah untuk mulai 🚀`,
    footer: `© ${new Date().getFullYear()} ${cfg.botName} | Created by ${cfg.ownerName}`,
    title: "📌 Pilih Menu",
    buttonText: "📂 Lihat Menu",
    sections
};

    await sock.sendMessage(m.chat, listMessage, { quoted: m });
    break;
      
case 'allmenu':
    const allMenuModern = `
 ✪〘 *${cfg.botName}* 〙✪
   Owner: ${cfg.ownerName}
   Prefix: ${cfg.prefix}
   Versi : ${cfg.version}
   🌐 ${cfg.website || '-'}
════════════════════

📜 *RPG Commands*
┌─────────────────
│ 🎯 ${cfg.prefix}rpg_status
│ 🎁 ${cfg.prefix}rpg_daily
│ 🏋️ ${cfg.prefix}rpg_train
│ 📖 ${cfg.prefix}rpg_qstart <name>
│ 🔄 ${cfg.prefix}rpg_qnext
│ 🏹 ${cfg.prefix}rpg_hunt
│ 🎣 ${cfg.prefix}rpg_fish
│ ⛏️ ${cfg.prefix}rpg_mine
│ 🔨 ${cfg.prefix}rpg_craft <item>
│ 🏪 ${cfg.prefix}rpg_shop
│ 🛒 ${cfg.prefix}rpg_buy <id>
│ 💰 ${cfg.prefix}rpg_sell <item>
│ 🎒 ${cfg.prefix}rpg_inv
│ ⚔️ ${cfg.prefix}rpg_duel <@id>
│ ❤️ ${cfg.prefix}rpg_heal
│ 💤 ${cfg.prefix}rpg_rest
│ ⬆️ ${cfg.prefix}rpg_upgrade
│ 📊 ${cfg.prefix}rpg_stats
│ 📜 ${cfg.prefix}rpg_recipes
│ 👹 ${cfg.prefix}rpg_summon <name>
│ 🐾 ${cfg.prefix}rpg_pet
│ 🐴 ${cfg.prefix}rpg_tame
│ 🐉 ${cfg.prefix}rpg_boss
│ 🗺️ ${cfg.prefix}rpg_explore
│ 🪄 ${cfg.prefix}rpg_skills
│ ✨ ${cfg.prefix}rpg_useskill <skill>
│ 🏆 ${cfg.prefix}rpg_lb
│ 🎁 ${cfg.prefix}rpg_give <@id> <amount>
└─────────────────

👥 *Group Commands*
┌─────────────────
│ 🙋 ${cfg.prefix}welcome_set <text>
│ 👋 ${cfg.prefix}goodbye_set <text>
│ 🙋 ${cfg.prefix}welcome
│ 👋 ${cfg.prefix}goodbye
│ 🔗 ${cfg.prefix}antilink_on
│ ❌ ${cfg.prefix}antilink_off
│ 🔗 ${cfg.prefix}antilinkgc_on
│ ❌ ${cfg.prefix}antilinkgc_off
│ 🤬 ${cfg.prefix}antitoxic_on
│ 😇 ${cfg.prefix}antitoxic_off
│ ➕ ${cfg.prefix}add <number>
│ ➖ ${cfg.prefix}kick <@id>
│ 📈 ${cfg.prefix}promote <@id>
│ 📉 ${cfg.prefix}demote <@id>
│ 📢 ${cfg.prefix}tagall
│ ✏️ ${cfg.prefix}setname <name>
│ 📝 ${cfg.prefix}setdesc <text>
│ 🔇 ${cfg.prefix}mute
│ 🔊 ${cfg.prefix}unmute
│ 🗳️ ${cfg.prefix}vote_start <topic>
│ ✅ ${cfg.prefix}vote <yes|no>
│ 🛑 ${cfg.prefix}vote_end
│ 📊 ${cfg.prefix}poll <question>
│ ⚠️ ${cfg.prefix}warn <@id>
│ ♻️ ${cfg.prefix}clearwarns <@id>
│ ⚙️ ${cfg.prefix}group_settings
│ 🛡️ ${cfg.prefix}tagadmins
│ 🧹 ${cfg.prefix}clearcache
│ 🚫 ${cfg.prefix}kickspam
│ 🎨 ${cfg.prefix}setwelcome_template
└─────────────────

🎭 *Fun Commands*
┌─────────────────
│ 💬 ${cfg.prefix}say <text>
│ 📝 ${cfg.prefix}quote
│ 😂 ${cfg.prefix}meme
│ 🎲 ${cfg.prefix}dadujal
│ 📚 ${cfg.prefix}fakta
│ ❓ ${cfg.prefix}tebak <jawaban>
│ 💞 ${cfg.prefix}jodoh <@id>
└─────────────────

🛠️ *Tools Commands*
┌─────────────────
│ 🌎 ${cfg.prefix}translate <lang> <text>
│ 🤖 ${cfg.prefix}ai <text>
│ 🖼️ ${cfg.prefix}image <text>
│ 🖼️ ${cfg.prefix}sticker
│ 📸 ${cfg.prefix}toimg
│ 🌐 ${cfg.prefix}ssweb <url>
│ 🎵 ${cfg.prefix}tomp3
│ 🎙️ ${cfg.prefix}tovn
└─────────────────

🏅 *User & Bot Info*
┌─────────────────
│ 📊 ${cfg.prefix}level
│ 💰 ${cfg.prefix}ceklimit
│ 👑 ${cfg.prefix}listowner
└─────────────────

⭐ *Owner Commands*
┌─────────────────
│ ➕ ${cfg.prefix}addowner <@id>
│ ➖ ${cfg.prefix}delowner <@id>
│ ➕ ${cfg.prefix}addlimit <@id> <amount>
│ ➖ ${cfg.prefix}dellimit <@id>
└─────────────────

📌 *Other Commands*
┌─────────────────
│ 📂 ${cfg.prefix}menu
│ 📍 ${cfg.prefix}ping
│ ℹ️ ${cfg.prefix}help
└─────────────────

💡 *Info Bot*
Dibuat oleh: ${cfg.ownerName}
GitHub: ${cfg.github || '-'}
Instagram: ${cfg.instagram || '-'}

_© ${new Date().getFullYear()} ${cfg.botName}_
    `;
    return reply(allMenuModern);
    break;
        
case 'rpgmenu':
    const rpgMenuModern = `
  ✪〘 *${cfg.botName}* 〙✪
   Owner: ${cfg.ownerName}
   Prefix: ${cfg.prefix}
   Versi : ${cfg.version}
   🌐 ${cfg.website || '-'}
════════════════════
    
 📜 *RPG Commands* ┌─────────────────
│ 🎯 ${cfg.prefix}rpg_status
│ 🎁 ${cfg.prefix}rpg_daily
│ 🏋️ ${cfg.prefix}rpg_train
│ 📖 ${cfg.prefix}rpg_qstart <name>
│ 🔄 ${cfg.prefix}rpg_qnext
│ 🏹 ${cfg.prefix}rpg_hunt
│ 🎣 ${cfg.prefix}rpg_fish
│ ⛏️ ${cfg.prefix}rpg_mine
│ 🔨 ${cfg.prefix}rpg_craft <item>
│ 🏪 ${cfg.prefix}rpg_shop
│ 🛒 ${cfg.prefix}rpg_buy <id>
│ 💰 ${cfg.prefix}rpg_sell <item>
│ 🎒 ${cfg.prefix}rpg_inv
│ ⚔️ ${cfg.prefix}rpg_duel <@id>
│ ❤️ ${cfg.prefix}rpg_heal
│ 💤 ${cfg.prefix}rpg_rest
│ ⬆️ ${cfg.prefix}rpg_upgrade
│ 📊 ${cfg.prefix}rpg_stats
│ 📜 ${cfg.prefix}rpg_recipes
│ 👹 ${cfg.prefix}rpg_summon <name>
│ 🐾 ${cfg.prefix}rpg_pet
│ 🐴 ${cfg.prefix}rpg_tame
│ 🐉 ${cfg.prefix}rpg_boss
│ 🗺️ ${cfg.prefix}rpg_explore
│ 🪄 ${cfg.prefix}rpg_skills
│ ✨ ${cfg.prefix}rpg_useskill <skill>
│ 🏆 ${cfg.prefix}rpg_lb
│ 🎁 ${cfg.prefix}rpg_give <@id> <amount>
└─────────────────
    `;
    return reply(rpgMenuModern);
    break;

case 'groupmenu':
    const groupMenuModern = `
 ✪〘 *${cfg.botName}* 〙✪
   Owner: ${cfg.ownerName}
   Prefix: ${cfg.prefix}
   Versi : ${cfg.version}
   🌐 ${cfg.website || '-'}
════════════════════
    
 👥 *Group Commands* ┌─────────────────
│ 🙋 ${cfg.prefix}welcome_set <text>
│ 👋 ${cfg.prefix}goodbye_set <text>
│ 🙋 ${cfg.prefix}welcome
│ 👋 ${cfg.prefix}goodbye
│ 🔗 ${cfg.prefix}antilink_on
│ ❌ ${cfg.prefix}antilink_off
│ 🔗 ${cfg.prefix}antilinkgc_on
│ ❌ ${cfg.prefix}antilinkgc_off
│ 🤬 ${cfg.prefix}antitoxic_on
│ 😇 ${cfg.prefix}antitoxic_off
│ ➕ ${cfg.prefix}add <number>
│ ➖ ${cfg.prefix}kick <@id>
│ 📈 ${cfg.prefix}promote <@id>
│ 📉 ${cfg.prefix}demote <@id>
│ 📢 ${cfg.prefix}tagall
│ ✏️ ${cfg.prefix}setname <name>
│ 📝 ${cfg.prefix}setdesc <text>
│ 🔇 ${cfg.prefix}mute
│ 🔊 ${cfg.prefix}unmute
│ 🗳️ ${cfg.prefix}vote_start <topic>
│ ✅ ${cfg.prefix}vote <yes|no>
│ 🛑 ${cfg.prefix}vote_end
│ 📊 ${cfg.prefix}poll <question>
│ ⚠️ ${cfg.prefix}warn <@id>
│ ♻️ ${cfg.prefix}clearwarns <@id>
│ ⚙️ ${cfg.prefix}group_settings
│ 🛡️ ${cfg.prefix}tagadmins
│ 🧹 ${cfg.prefix}clearcache
│ 🚫 ${cfg.prefix}kickspam
│ 🎨 ${cfg.prefix}setwelcome_template
└─────────────────
    `;
    return reply(groupMenuModern);
    break;

case 'funmenu':
    const funMenuModern = `
 ✪〘 *${cfg.botName}* 〙✪
   Owner: ${cfg.ownerName}
   Prefix: ${cfg.prefix}
   Versi : ${cfg.version}
   🌐 ${cfg.website || '-'}
════════════════════
    
 🎭 *Fun Commands* ┌─────────────────
│ 💬 ${cfg.prefix}say <text>
│ 📝 ${cfg.prefix}quote
│ 😂 ${cfg.prefix}meme
│ 🎲 ${cfg.prefix}dadujal
│ 📚 ${cfg.prefix}fakta
│ ❓ ${cfg.prefix}tebak <jawaban>
│ 💞 ${cfg.prefix}jodoh <@id>
│ 🗣️ ${cfg.prefix}caklontong
│ 🤜 ${cfg.prefix}suit <batu|kertas|gunting>
│ 🎰 ${cfg.prefix}slot
│ ❔ ${cfg.prefix}apakah <question>
│ ⏳ ${cfg.prefix}kapankah <question>
└─────────────────
    `;
    return reply(funMenuModern);
    break;

case 'toolsmenu':
    const toolsMenuModern = `
 ✪〘 *${cfg.botName}* 〙✪
   Owner: ${cfg.ownerName}
   Prefix: ${cfg.prefix}
   Versi : ${cfg.version}
   🌐 ${cfg.website || '-'}
════════════════════
    
 🛠️ *Tools Commands* ┌─────────────────
│ 🌎 ${cfg.prefix}translate <lang> <text>
│ 🤖 ${cfg.prefix}ai <text>
│ 🖼️ ${cfg.prefix}image <text>
│ 🖼️ ${cfg.prefix}sticker
│ 📸 ${cfg.prefix}toimg
│ 🌐 ${cfg.prefix}ssweb <url>
│ 🎵 ${cfg.prefix}tomp3
│ 🎙️ ${cfg.prefix}tovn
└─────────────────
    `;
    return reply(toolsMenuModern);
    break;

      // ----------------------
      // RPG namespace (prefix rpg_)
      // ----------------------
      case 'rpg_status': {
        const user = storage.getUser(uid);
        storage.saveUser(uid, user);
        return reply(rpg.status(user));
      }
      break;

      case 'rpg_daily': {
        const user = storage.getUser(uid);
        const now = Date.now();
        const res = rpg.daily(user, now);
        storage.saveUser(uid, user);
        return reply(res.msg || res);
      }
      break;

      case 'rpg_train': {
        const user = storage.getUser(uid);
        const res = rpg.train(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_qstart': {
        const user = storage.getUser(uid);
        const name = args.join(' ') || '未知任务';
        const res = rpg.questStart(user, name);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_qnext':
      case 'rpg_quest': {
        const user = storage.getUser(uid);
        const res = rpg.questProgress(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_hunt': {
        const user = storage.getUser(uid);
        const res = rpg.hunt(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_fish': {
        const user = storage.getUser(uid);
        const res = rpg.fish(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_mine': {
        const user = storage.getUser(uid);
        const res = rpg.mine(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_craft': {
        const user = storage.getUser(uid);
        const item = args.join(' ');
        const res = rpg.craft(user, item);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_shop': {
        const items = rpg.shop();
        return reply('Shop:\n' + items.map(i=>`${i.id} - ${i.name} : ${i.price}G`).join('\n'));
      }
      break;

      case 'rpg_buy': {
        const user = storage.getUser(uid);
        const id = args[0];
        const res = rpg.buy(user, id);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_sell': {
        const user = storage.getUser(uid);
        const item = args.join(' ');
        const res = rpg.sell(user, item);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_inv':
      case 'rpg_inventory': {
        const user = storage.getUser(uid);
        return reply(rpg.inventory(user));
      }
      break;

      case 'rpg_duel': {
        const user = storage.getUser(uid);
        const opp = args[0] || null;
        if (!opp) return reply('Tentukan target duel: !rpg_duel <@id>');
        const oppObj = storage.getUser(opp.replace(/[^0-9@.]/g,'') || opp);
        const res = rpg.duel(user, oppObj);
        storage.saveUser(uid, user);
        storage.saveUser(oppObj.id || opp, oppObj);
        return reply(res);
      }
      break;

      case 'rpg_heal': {
        const user = storage.getUser(uid);
        const res = rpg.heal(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_rest': {
        const user = storage.getUser(uid);
        const res = rpg.rest(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_upgrade': {
        const user = storage.getUser(uid);
        const res = rpg.upgrade(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_stats': {
        const user = storage.getUser(uid);
        return reply(rpg.stats(user));
      }
      break;

      case 'rpg_recipes': {
        return reply('Recipes:\n' + rpg.recipes().join('\n'));
      }
      break;

      case 'rpg_summon': {
        const user = storage.getUser(uid);
        const name = args.join(' ') || '小灵兽';
        const res = rpg.summon(user, name);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_pet': {
        const user = storage.getUser(uid);
        return reply(rpg.petStatus(user));
      }
      break;

      case 'rpg_tame': {
        const user = storage.getUser(uid);
        const res = rpg.tame(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_boss': {
        const user = storage.getUser(uid);
        const res = rpg.boss(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_explore': {
        const user = storage.getUser(uid);
        const res = rpg.explore(user);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_skills': {
        return reply('Skills:\n' + rpg.skills().join('\n'));
      }
      break;

      case 'rpg_useskill': {
        const user = storage.getUser(uid);
        const skill = args[0];
        const res = rpg.useSkill(user, skill);
        storage.saveUser(uid, user);
        return reply(res);
      }
      break;

      case 'rpg_lb':
      case 'rpg_leaderboard': {
        const db = require('./src/storage').read();
        return reply(rpg.leaderboard(db.users));
      }
      break;

      case 'rpg_give': {
        const user = storage.getUser(uid);
        const to = args[0];
        const amount = Number(args[1]) || 0;
        if (!to) return reply('Gunakan: !rpg_give <@id> <amount>');
        const toId = to.replace(/[^0-9@.]/g,'') || to;
        const target = storage.getUser(toId);
        const res = rpg.give(user, target, amount);
        storage.saveUser(uid, user);
        storage.saveUser(toId, target);
        return reply(res);
      }
      break;

      // ----------------------
      // Group features (30 features - persistent + real group ops when sock available)
      // ----------------------

      case 'welcome_set': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        const text = args.join(' ') || '欢迎 {name}';
        groupUtil.setWelcome(g, text);
        storage.saveGroup(gid, g);
        return reply('Welcome message sudah disimpan.');
      }
      break;

      case 'goodbye_set': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        const text = args.join(' ') || '再见 {name}';
        groupUtil.setGoodbye(g, text);
        storage.saveGroup(gid, g);
        return reply('Goodbye message sudah disimpan.');
      }
      break;

      case 'welcome': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        const name = args.join(' ') || '新朋友';
        return reply(g.welcome ? g.welcome.replace('{name}', name) : `欢迎 ${name}`);
      }
      break;

      case 'goodbye': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        const name = args.join(' ') || '朋友';
        return reply(g.goodbye ? g.goodbye.replace('{name}', name) : `再见 ${name}`);
      }
      break;

      case 'antilink_on': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        g.antilink = true; storage.saveGroup(gid, g);
        return reply('Antilink aktif.');
      }
      break;

      case 'antilink_off': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        g.antilink = false; storage.saveGroup(gid, g);
        return reply('Antilink nonaktif.');
      }
      break;

      case 'antilinkgc_on': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid); g.antilinkgc = true; storage.saveGroup(gid, g);
        return reply('AntilinkGC aktif.');
      }
      break;

      case 'antilinkgc_off': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid); g.antilinkgc = false; storage.saveGroup(gid, g);
        return reply('AntilinkGC nonaktif.');
      }
      break;

      case 'antitoxic_on': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid); g.antitoxic = true; storage.saveGroup(gid, g);
        return reply('Antitoxic aktif.');
      }
      break;

      case 'antitoxic_off': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid); g.antitoxic = false; storage.saveGroup(gid, g);
        return reply('Antitoxic nonaktif.');
      }
      break;

      case 'add': {
        if (!sock) return reply('Operasi add memerlukan koneksi WA (tidak di MOCK).');
        if (!gid) return reply('Perintah ini harus di group.');
        const number = args[0];
        if (!number) return reply('Gunakan: !add 6289xxxxxx');
        try {
          await sock.groupAdd(gid, [number + '@s.whatsapp.net']);
          return reply('Menambahkan user (request dikirim).');
        } catch(e) {
          return reply('Gagal menambahkan: ' + (e.message || e));
        }
      }
      break;

      case 'kick': {
        if (!sock) return reply('Operasi kick memerlukan koneksi WA (tidak di MOCK).');
        if (!gid) return reply('Perintah ini harus di group.');
        const target = args[0];
        if (!target) return reply('Gunakan: !kick <@id>');
        const jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        try {
          await sock.groupParticipantsUpdate(gid, [jid], 'remove');
          return reply('User dikick.');
        } catch(e) {
          return reply('Gagal kick: ' + e.message);
        }
      }
      break;

      case 'promote': {
        if (!sock) return reply('Operasi promote memerlukan koneksi WA.');
        if (!gid) return reply('Perintah ini harus di group.');
        const ptarget = args[0];
        if (!ptarget) return reply('Gunakan: !promote <@id>');
        const pj = ptarget.replace(/[^0-9]/g,'') + '@s.whatsapp.net';
        try {
          await sock.groupParticipantsUpdate(gid, [pj], 'promote');
          return reply('User dipromote jadi admin.');
        } catch(e) { return reply('Gagal promote: ' + e.message); }
      }
      break;

      case 'demote': {
        if (!sock) return reply('Operasi demote memerlukan koneksi WA.');
        if (!gid) return reply('Perintah ini harus di group.');
        const dtarget = args[0];
        if (!dtarget) return reply('Gunakan: !demote <@id>');
        const dj = dtarget.replace(/[^0-9]/g,'') + '@s.whatsapp.net';
        try {
          await sock.groupParticipantsUpdate(gid, [dj], 'demote');
          return reply('User didemote.');
        } catch(e) { return reply('Gagal demote: ' + e.message); }
      }
      break;

      case 'tagall': {
        if (!gid) return reply('Perintah ini harus di group.');
        if (!sock) return reply('Tagall memerlukan koneksi WA.');
        try {
          const metadata = await sock.groupMetadata(gid);
          const participants = metadata.participants || [];
          const mentions = participants.map(p=>p.id);
          const text = 'Mention semua:';
          await sock.sendMessage(gid, { text, mentions });
          return reply('Selesai tagall.');
        } catch(e) {
          return reply('Gagal tagall: ' + e.message);
        }
      }
      break;

      case 'setname': {
        if (!gid) return reply('Perintah ini harus di group.');
        if (!sock) return reply('setname memerlukan koneksi WA.');
        const name = args.join(' ');
        if (!name) return reply('Gunakan: !setname <nama group>');
        try {
          await sock.groupUpdateSubject(gid, name);
          return reply('Nama group diganti.');
        } catch(e) { return reply('Gagal setname: ' + e.message); }
      }
      break;

      case 'setdesc': {
        if (!gid) return reply('Perintah ini harus di group.');
        if (!sock) return reply('setdesc memerlukan koneksi WA.');
        const text = args.join(' ');
        if (!text) return reply('Gunakan: !setdesc <deskripsi>');
        try {
          await sock.groupUpdateDescription(gid, text);
          return reply('Deskripsi group diubah.');
        } catch(e) { return reply('Gagal setdesc: ' + e.message); }
      }
      break;

      case 'mute': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        g.settings.muted = true; storage.saveGroup(gid, g);
        return reply('Group dimute (note: tidak memblokir message, hanya setting).');
      }
      break;

      case 'unmute': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        g.settings.muted = false; storage.saveGroup(gid, g);
        return reply('Group unmute.');
      }
      break;

      case 'vote_start': {
        if (!gid) return reply('Perintah ini harus di group.');
        const topic = args.join(' ') || 'Vote';
        const db = require('./src/storage').read();
        db.groups[gid].vote = { topic, yes:0, no:0, voters: {} };
        require('./src/storage').write(db);
        return reply(`Vote dimulai: ${topic}`);
      }
      break;

      case 'vote': {
        if (!gid) return reply('Perintah ini harus di group.');
        const choice = args[0];
        if (!choice || !['yes','no'].includes(choice)) return reply('Gunakan: !vote yes|no');
        const db = require('./src/storage').read();
        const vote = db.groups[gid].vote;
        if(!vote) return reply('Belum ada vote aktif.');
        const voter = uid;
        if (vote.voters[voter]) return reply('Kamu sudah voting.');
        vote.voters[voter] = choice;
        vote[choice] += 1;
        require('./src/storage').write(db);
        return reply('Vote dicatat.');
      }
      break;

      case 'vote_end': {
        if (!gid) return reply('Perintah ini harus di group.');
        const db = require('./src/storage').read();
        const vote = db.groups[gid].vote;
        if(!vote) return reply('Belum ada vote.');
        const res = `Vote: ${vote.topic}\nYes: ${vote.yes}\nNo: ${vote.no}`;
        delete db.groups[gid].vote;
        require('./src/storage').write(db);
        return reply(res);
      }
      break;

      case 'poll': {
        if (!gid) return reply('Perintah ini harus di group.');
        const question = args.join(' ') || 'Poll';
        return reply(`Poll: ${question}\nGunakan !vote yes atau !vote no`);
      }
      break;

      case 'warn': {
        if (!gid) return reply('Perintah ini harus di group.');
        const target = args[0];
        if (!target) return reply('Gunakan: !warn <@id>');
        const id = target.replace(/[^0-9]/g,'') + '@s.whatsapp.net';
        const db = require('./src/storage').read();
        const warns = (db.groups[gid].warns = db.groups[gid].warns || {});
        warns[id] = (warns[id] || 0) + 1;
        require('./src/storage').write(db);
        return reply(`Warn diberikan ke ${id}. Total: ${warns[id]}`);
      }
      break;

      case 'clearwarns': {
        if (!gid) return reply('Perintah ini harus di group.');
        const target = args[0];
        if (!target) return reply('Gunakan: !clearwarns <@id>');
        const id = target.replace(/[^0-9]/g,'') + '@s.whatsapp.net';
        const db = require('./src/storage').read();
        const warns = (db.groups[gid].warns = db.groups[gid].warns || {});
        warns[id] = 0;
        require('./src/storage').write(db);
        return reply(`Warn di-reset untuk ${id}`);
      }
      break;

      case 'group_settings': {
        if (!gid) return reply('Perintah ini harus di group.');
        const g = storage.getGroup(gid);
        return reply('Group settings: ' + JSON.stringify(g.settings || {}, null, 2));
      }
      break;

      case 'tagadmins': {
        if (!gid) return reply('Perintah ini harus di group.');
        if (!sock) return reply('Memerlukan koneksi WA.');
        try {
          const meta = await sock.groupMetadata(gid);
          const admins = meta.participants.filter(p=>p.admin).map(a=>a.id);
          await sock.sendMessage(gid, { text: 'Admins:', mentions: admins });
          return reply('Admins ditag.');
        } catch(e) { return reply('Gagal tagadmins: ' + e.message); }
      }
      break;

      case 'clearcache': {
        const fs = require('fs');
        const p = require('path').join(__dirname, 'data.json');
        if (fs.existsSync(p)) { fs.unlinkSync(p); return reply('Cache data dihapus.'); }
        return reply('Tidak ada cache.');
      }
      break;

      case 'kickspam': {
        if (!gid) return reply('Perintah ini harus di group.');
        if (!sock) return reply('Memerlukan koneksi WA.');
        try {
          const meta = await sock.groupMetadata(gid);
          const toKick = meta.participants.filter(p=>!p.admin).map(p=>p.id);
          await sock.groupParticipantsUpdate(gid, toKick, 'remove');
          return reply('Selesai kick non-admin (perintah agresif).');
        } catch(e) { return reply('Gagal kickspam: ' + e.message); }
      }
      break;

      case 'setwelcome_template': {
        if (!gid) return reply('Perintah ini harus di group.');
        return reply('Template tersedia: {name} untuk nama user.');
      }
      break;

      // ----------------------
      // Fun features
      // ----------------------

      case 'say': {
        const message = args.join(' ');
        if (!message) return reply('Mau bilang apa? !say <text>');
        return reply(message);
      }
      break;

      case 'quote': {
        const quotes = [
          "Hidup itu seperti naik sepeda. Untuk menjaga keseimbangan, kamu harus terus bergerak.",
          "Satu-satunya cara untuk melakukan pekerjaan hebat adalah dengan mencintai apa yang kamu lakukan.",
          "Kegagalan adalah bumbu kehidupan.",
          "Jika kamu tidak bisa terbang, maka berlarilah. Jika kamu tidak bisa berlari, maka berjalanlah. Jika kamu tidak bisa berjalan, merangkaklah. Apa pun yang kamu lakukan, kamu harus terus maju.",
          "Kebahagiaan adalah ketika apa yang kamu pikirkan, apa yang kamu katakan, dan apa yang kamu lakukan berada dalam harmoni.",
        ];
        const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
        return reply(randomQuote);
      }
      break;

      case 'meme': {
        try {
          const response = await axios.get('https://meme-api.com/gimme');
          const meme = response.data;
          if (meme.nsfw) {
            return reply('Maaf, meme ini NSFW.');
          }
          await sock.sendMessage(from, { image: { url: meme.url }, caption: meme.title });
        } catch(e) {
          return reply('Gagal mengambil meme: ' + e.message);
        }
      }
      break;

      case 'dadujal': {
        return reply('Dadujal adalah salah satu fitur fun, tapi belum ada isinya. Mungkin di masa depan akan ada kejutan!');
      }
      break;

      case 'fakta': {
        const fakta = [
          "Jantung udang berada di kepalanya.",
          "Semut tidak pernah tidur.",
          "Kucing menghabiskan 70% hidupnya untuk tidur.",
          "Panda makan sekitar 12 jam sehari.",
          "Otak manusia 75% terdiri dari air.",
        ];
        const randomFakta = fakta[Math.floor(Math.random() * fakta.length)];
        return reply(randomFakta);
      }
      break;
      
      case 'tebak': {
        const tebakan = [
          { q: "Apa yang punya leher dan tidak punya kepala?", a: "baju" },
          { q: "Saya selalu datang tapi tidak pernah tiba. Siapakah saya?", a: "besok" },
          { q: "Apa yang selalu bertambah tapi tidak pernah berkurang?", a: "umur" },
        ];
        const game = storage.getGame(gid || uid, 'tebak');
        if (!game || !game.active) {
            const randomTebak = tebakan[Math.floor(Math.random() * tebakan.length)];
            storage.setGame(gid || uid, 'tebak', { active: true, question: randomTebak.q, answer: randomTebak.a });
            return reply(`Tebak-tebakan: ${randomTebak.q}`);
        } else {
            const userAnswer = args.join(' ').toLowerCase();
            if (userAnswer === game.answer) {
                storage.deleteGame(gid || uid, 'tebak');
                return reply('Benar! Jawabanmu tepat.');
            } else {
                return reply('Salah! Coba lagi.');
            }
        }
      }
      break;

      case 'jodoh': {
        const target = args[0] || '';
        const user = uid.split('@')[0];
        const targetId = target.replace(/[^0-9]/g,'').split('@')[0];
        if (!targetId) return reply('Gunakan: !jodoh <@id>');
        
        const hash = user.length + targetId.length;
        const result = hash % 101;
        
        let message = `Tingkat kecocokan jodoh antara @${user} dan @${targetId} adalah ${result}%!`;
        if (result > 80) message += ' Waw, sepertinya kalian ditakdirkan bersama!';
        else if (result > 50) message += ' Lumayan, masih ada harapan.';
        else message += ' Hmm, mungkin kalian lebih cocok jadi teman.';
        
        await sock.sendMessage(from, { text: message, mentions: [uid, target] });
      }
      break;
      
      case 'caklontong': {
        const caklontongQuestions = [
          { q: "Orang yang suka makan teman adalah...", a: "teman" },
          { q: "Kalo pacar minta mobil, mintalah...", a: "motor" },
        ];
        const game = storage.getGame(gid || uid, 'caklontong');
        if (!game || !game.active) {
            const randomCak = caklontongQuestions[Math.floor(Math.random() * caklontongQuestions.length)];
            storage.setGame(gid || uid, 'caklontong', { active: true, question: randomCak.q, answer: randomCak.a });
            return reply(`Tebak Cak Lontong: ${randomCak.q}`);
        } else {
            const userAnswer = args.join(' ').toLowerCase();
            if (userAnswer.includes(game.answer)) {
                storage.deleteGame(gid || uid, 'caklontong');
                return reply(`Betul! Jawabannya adalah *${game.answer}*`);
            } else {
                return reply('Kurang tepat, coba lagi!');
            }
        }
      }
      break;

      case 'suit': {
        const choices = ['batu', 'kertas', 'gunting'];
        const userChoice = args[0] ? args[0].toLowerCase() : '';
        if (!choices.includes(userChoice)) {
          return reply('Pilih salah satu: batu, kertas, gunting.');
        }

        const botChoice = choices[Math.floor(Math.random() * choices.length)];
        let result = '';

        if (userChoice === botChoice) {
          result = 'Seri!';
        } else if (
          (userChoice === 'batu' && botChoice === 'gunting') ||
          (userChoice === 'kertas' && botChoice === 'batu') ||
          (userChoice === 'gunting' && botChoice === 'kertas')
        ) {
          result = 'Kamu menang!';
        } else {
          result = 'Bot menang!';
        }

        return reply(`Kamu memilih ${userChoice}, bot memilih ${botChoice}. ${result}`);
      }
      break;
      
      case 'slot': {
        const items = ['🍒', '🍋', '🔔', '🍇', '🍉'];
        const reel1 = items[Math.floor(Math.random() * items.length)];
        const reel2 = items[Math.floor(Math.random() * items.length)];
        const reel3 = items[Math.floor(Math.random() * items.length)];

        let resultText = `[ ${reel1} | ${reel2} | ${reel3} ]\n`;

        if (reel1 === reel2 && reel2 === reel3) {
          resultText += 'Selamat! Jackpot!';
        } else if (reel1 === reel2 || reel2 === reel3 || reel1 === reel3) {
          resultText += 'Hampir! Kamu menang sedikit.';
        } else {
          resultText += 'Coba lagi lain kali.';
        }
        return reply(resultText);
      }
      break;

      case 'apakah': {
        const yesNo = ['Ya', 'Tidak'];
        const result = yesNo[Math.floor(Math.random() * yesNo.length)];
        return reply(result);
      }
      break;

      case 'kapankah': {
        const when = [
          "Besok", "Lusa", "Minggu depan", "Bulan depan", "Tahun depan", "Nanti malam",
          "Nanti sore", "Sekarang juga", "Tidak akan pernah", "Entah", "Coba tanyakan lagi",
        ];
        const result = when[Math.floor(Math.random() * when.length)];
        return reply(result);
      }
      break;

      // ----------------------
      // Tools
      // ----------------------

      case 'translate': {
        if (args.length < 2) return reply('Gunakan: !translate <lang> <text>');
        const lang = args[0];
        const textToTranslate = args.slice(1).join(' ');
        try {
          // Replace with a real translation API, e.g., Google Translate API
          const response = await axios.get(`https://api.somemagictranslator.com/translate?lang=${lang}&text=${encodeURIComponent(textToTranslate)}`);
          return reply(response.data.translation);
        } catch(e) {
          return reply('Gagal menerjemahkan. Pastikan kode bahasa benar.');
        }
      }
      break;

      case 'ai': {
        const query = args.join(' ');
        if (!query) return reply('Ajukan pertanyaan: !ai <pertanyaan>');
        try {
          // Replace with a real AI API, e.g., OpenAI, Gemini
          const response = await axios.post('https://api.somemagicai.com/ask', { prompt: query });
          return reply(response.data.response);
        } catch(e) {
          return reply('Maaf, saya sedang tidak bisa menjawab sekarang.');
        }
      }
      break;

      case 'image': {
        const query = args.join(' ');
        if (!query) return reply('Tuliskan deskripsi gambar: !image <deskripsi>');
        try {
          // Replace with a real image generation API, e.g., DALL-E, Stable Diffusion
          const response = await axios.post('https://api.someimagedb.com/generate', { prompt: query });
          await sock.sendMessage(from, { image: { url: response.data.imageUrl }, caption: 'Ini gambar yang kamu minta.' });
        } catch(e) {
          return reply('Gagal membuat gambar.');
        }
      }
      break;

      case 'sticker': {
        if (!msg || !msg.message) {
          return reply('Balas gambar untuk membuat stiker.');
        }
        
        const media = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
        if (media && media.imageMessage) {
            const stream = await downloadMediaMessage(media, 'stream');
            const buffer = await getBufferFromStream(stream);
            await sock.sendMessage(from, { sticker: buffer });
        } else {
            return reply('Balas gambar untuk membuat stiker.');
        }
      }
      break;

      case 'toimg': {
        if (!msg || !msg.message || !msg.message.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage) {
          return reply('Balas stiker untuk mengubahnya menjadi gambar.');
        }
        
        const stickerMsg = msg.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage;
        const stream = await downloadMediaMessage(stickerMsg, 'stream');
        const buffer = await getBufferFromStream(stream);
        
        await sock.sendMessage(from, { image: buffer });
      }
      break;
      
      case 'ssweb': {
        const url = args[0];
        if (!url) return reply('Masukkan URL: !ssweb <url>');
        try {
            const screenshotUrl = `https://api.someweirdapi.com/screenshot?url=${encodeURIComponent(url)}`;
            await sock.sendMessage(from, { image: { url: screenshotUrl }, caption: `Screenshot dari ${url}` });
        } catch(e) {
            return reply('Gagal mengambil screenshot.');
        }
      }
      break;
      
      case 'tomp3': {
        if (!msg || !msg.message) {
          return reply('Balas video untuk mengkonversinya.');
        }

        const media = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
        if (media && (media.videoMessage || media.audioMessage)) {
            // Placeholder: A real implementation would download the media, convert it, then send it back.
            // This is a complex task requiring ffmpeg or similar libraries.
            return reply('Fitur ini masih dalam pengembangan. Silakan coba lagi nanti.');
        } else {
            return reply('Balas video atau audio untuk mengkonversinya ke mp3.');
        }
      }
      break;

      case 'tovn': {
        if (!msg || !msg.message) {
          return reply('Balas video atau audio untuk mengkonversinya.');
        }

        const media = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
        if (media && (media.videoMessage || media.audioMessage)) {
            // Placeholder: A real implementation would download the media, convert it to an OPUS file, and send as a voice note.
            return reply('Fitur ini masih dalam pengembangan. Silakan coba lagi nanti.');
        } else {
            return reply('Balas video atau audio untuk mengkonversinya ke voice note.');
        }
      }
      break;

      // default unknown
      default:
        return reply(`未知指令 / Command tidak dikenal: ${cmd}`);
    }
  } catch (e) {
    console.error('handleCommand error', e);
    return reply('Terjadi error saat mengeksekusi perintah: ' + (e.message || e));
  }
}

module.exports = { handleCommand };
