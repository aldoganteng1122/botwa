# Ying Yue (映月) - Full WhatsApp Bot

Contains:
- case.js (root) : switch-based command handler (all commands here)
- src/index.js   : entrypoint, Baileys connection, passes sock into handler
- src/function.js: helpers (parseCommand, formatTime, etc)
- src/storage.js : persistent JSON storage (users, groups, rpg data, settings)
- src/rpg.js     : RPG logic (28 fitur)
- src/group.js   : group utilities (30 fitur)
- config/config.json : basic config

## Run
1. Unzip project
2. `npm install`
3. `npm start` (or `MOCK=true npm start` for local testing without WA)

Prefix default: `!`

